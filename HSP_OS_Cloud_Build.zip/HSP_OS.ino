#include <Arduino.h>

static constexpr char HSP_VERSION[] = "0.1";
static constexpr char HSP_NAME[] = "HSP OS";

void setup() {
  Serial.begin(115200);
  delay(800);

  Serial.println();
  Serial.println("==============================");
  Serial.println("          HSP OS");
  Serial.println("         MK KERNEL");
  Serial.println("==============================");
  Serial.printf("Version: %s\n", HSP_VERSION);
  Serial.printf("Target: ESP32-S3\n");
  Serial.printf("CPU: %u MHz\n", getCpuFrequencyMhz());
  Serial.printf("Flash size: %u bytes\n", ESP.getFlashChipSize());
  Serial.printf("PSRAM: %u bytes\n", ESP.getPsramSize());
  Serial.println("Boot test complete.");
}

void loop() {
  static uint32_t last = 0;
  if (millis() - last >= 3000) {
    last = millis();
    Serial.printf("[%s] uptime: %lu ms\n", HSP_NAME, (unsigned long)millis());
  }
}
