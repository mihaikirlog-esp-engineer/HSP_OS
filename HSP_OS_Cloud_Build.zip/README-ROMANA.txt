HSP OS — Cloud Build starter
===========================

Configuratie tintita:
- ESP32-S3
- 16 MB Flash
- 8 MB PSRAM OPI
- Arduino-ESP32 core 3.3.5

IMPORTANT:
Acesta este un proiect de pornire pentru compilare, nu un firmware validat
pe placa fizica. Codul actual este un test serial, fara driver pentru display.

CUM SE FOLOSESTE:
1. Creeaza un repository GitHub si incarca tot continutul arhivei.
2. Deschide Actions si ruleaza workflow-ul "Build HSP OS".
3. Daca build-ul reuseste, descarca artifact-ul HSP-OS-ESP32-S3-build.
4. Verifica fisierele generate si configuratia placii inainte de orice flash.

NU FLASH-Ul:
- Nu presupune ca offseturile din alte tutoriale se potrivesc.
- Nu apasa Erase Flash.
- Nu folosi acest build pentru instalare pe placa pana nu verificam
  fisierul de bootloader, tabela de partitii, dimensiunile si offseturile
  raportate de build si configuratia exacta a placii.
- Daca PSRAM=opi sau FlashSize=16M nu este acceptat de versiunea core,
  workflow-ul va esua si trebuie ajustata configuratia inainte de flash.

Flasher-ul ESP32 Flash/Erase doar scrie fisierele binare; nu le compileaza.
